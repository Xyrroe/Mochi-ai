package com.example.mochi

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

/** Maskot orisinal "Mochi": makhluk bulat mint dengan tunas daun di kepala, digambar langsung dengan Canvas. */
class MascotView(context: Context) : View(context) {

    enum class Mood { IDLE, THINKING, TALKING }

    var mood: Mood = Mood.IDLE
        set(value) { field = value; invalidate() }

    private val d = resources.displayMetrics.density
    private fun dp(v: Float) = v * d

    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFBDEFD3.toInt() }
    private val bellyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFE4FAEE.toInt() }
    private val leafPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF5CC48A.toInt() }
    private val eyePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF1F2A33.toInt() }
    private val shinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }
    private val cheekPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x88FF9EB5.toInt() }
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x22000000 }
    private val mouthPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF1F2A33.toInt()
        style = Paint.Style.STROKE
        strokeWidth = dp(2f)
        strokeCap = Paint.Cap.ROUND
    }
    private val mouthFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF7A2E3E.toInt() }

    private var t = 0f
    private val rect = RectF()

    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1800
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedFraction; invalidate() }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val s = dp(96f).toInt()
        setMeasuredDimension(s, s)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val phase = (t * 2 * PI).toFloat()
        val bob = sin(phase) * dp(2.5f)
        val squash = 1f + 0.03f * sin(phase)

        // bayangan di tanah
        rect.set(cx - w * 0.30f, h * 0.90f, cx + w * 0.30f, h * 0.97f)
        canvas.drawOval(rect, shadowPaint)

        canvas.save()
        canvas.translate(0f, bob)
        canvas.scale(1f / squash, squash, cx, h * 0.88f)

        // tunas daun
        canvas.save()
        canvas.rotate(-28f, cx, h * 0.32f)
        rect.set(cx - dp(5f), h * 0.12f, cx + dp(5f), h * 0.36f)
        canvas.drawOval(rect, leafPaint)
        canvas.restore()
        canvas.save()
        canvas.rotate(28f, cx, h * 0.32f)
        rect.set(cx - dp(5f), h * 0.12f, cx + dp(5f), h * 0.36f)
        canvas.drawOval(rect, leafPaint)
        canvas.restore()

        // badan
        rect.set(w * 0.10f, h * 0.30f, w * 0.90f, h * 0.90f)
        canvas.drawOval(rect, bodyPaint)
        rect.set(w * 0.28f, h * 0.60f, w * 0.72f, h * 0.88f)
        canvas.drawOval(rect, bellyPaint)

        // mata (berkedip tiap ~3 detik)
        val blinking = System.currentTimeMillis() % 3200L < 140L
        val eyeY = h * 0.55f
        val eyeDx = w * 0.17f
        val look = if (mood == Mood.THINKING) dp(2.5f) else 0f
        val eyeR = dp(5.5f)
        for (side in intArrayOf(-1, 1)) {
            val ex = cx + side * eyeDx + look
            val ey = eyeY - look
            if (blinking) {
                canvas.drawLine(ex - eyeR, ey, ex + eyeR, ey, mouthPaint)
            } else {
                canvas.drawCircle(ex, ey, eyeR, eyePaint)
                canvas.drawCircle(ex + eyeR * 0.3f, ey - eyeR * 0.3f, eyeR * 0.35f, shinePaint)
            }
        }

        // pipi
        canvas.drawCircle(cx - w * 0.29f, h * 0.65f, dp(5.5f), cheekPaint)
        canvas.drawCircle(cx + w * 0.29f, h * 0.65f, dp(5.5f), cheekPaint)

        // mulut
        val my = h * 0.67f
        when (mood) {
            Mood.TALKING -> {
                val open = abs(sin(phase * 4f)) * dp(5f) + dp(2f)
                rect.set(cx - dp(5f), my - open / 2, cx + dp(5f), my + open / 2)
                canvas.drawOval(rect, mouthFill)
            }
            Mood.THINKING -> canvas.drawLine(cx - dp(3f), my, cx + dp(3f), my, mouthPaint)
            Mood.IDLE -> {
                rect.set(cx - dp(6f), my - dp(5f), cx + dp(6f), my + dp(3f))
                canvas.drawArc(rect, 20f, 140f, false, mouthPaint)
            }
        }
        canvas.restore()

        // titik "mikir..." di atas kepala
        if (mood == Mood.THINKING) {
            for (i in 0..2) {
                val on = ((t * 3).toInt() % 3) >= i
                val p = if (on) eyePaint else shadowPaint
                canvas.drawCircle(w * 0.76f + i * dp(7f), h * 0.20f, dp(2.5f), p)
            }
        }
    }
}
