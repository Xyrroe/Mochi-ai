package com.example.mochi

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInferenceSession
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors

/**
 * Pembungkus AI offline (MediaPipe LLM Inference). Cocok untuk model Gemma format .task.
 * Seluruh proses berjalan di HP, tanpa internet.
 */
class LlmEngine(private val context: Context) {

    private var llm: LlmInference? = null
    private var session: LlmInferenceSession? = null
    private val worker = Executors.newSingleThreadExecutor()

    // Riwayat obrolan: pasangan (peran, isi). Peran: "user" atau "model".
    private val history = mutableListOf<Pair<String, String>>()

    @Volatile
    var ready = false
        private set

    suspend fun load(modelPath: String) = withContext(Dispatchers.Default) {
        close()
        val options = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(modelPath)
            .setMaxTokens(1024)
            .build()
        llm = LlmInference.createFromOptions(context, options)
        ready = true
    }

    /**
     * Kirim pesan. [onResult] dipanggil berulang dari thread latar belakang:
     * (potongan teks baru, apakah sudah selesai).
     */
    fun ask(userText: String, systemPrompt: String, onResult: (String, Boolean) -> Unit) {
        val engine = llm ?: return onResult("(model belum siap)", true)
        history.add("user" to userText)
        val prompt = buildPrompt(systemPrompt)

        worker.execute {
            try {
                session?.close()
                val opts = LlmInferenceSession.LlmInferenceSessionOptions.builder()
                    .setTopK(40)
                    .setTemperature(0.8f)
                    .build()
                val s = LlmInferenceSession.createFromOptions(engine, opts)
                session = s
                s.addQueryChunk(prompt)
                s.generateResponseAsync { partial, done -> onResult(partial ?: "", done) }
            } catch (e: Throwable) {
                if (history.isNotEmpty() && history.last().first == "user") history.removeAt(history.lastIndex)
                onResult("(ups, ada error: ${e.message?.take(100)})", true)
            }
        }
    }

    /** Simpan jawaban AI ke riwayat supaya obrolan nyambung. */
    fun remember(reply: String) {
        if (reply.isNotBlank()) history.add("model" to reply)
        while (history.size > 14) history.removeAt(0)
        // Pastikan riwayat selalu diawali giliran "user"
        while (history.isNotEmpty() && history.first().first != "user") history.removeAt(0)
    }

    fun clearHistory() = history.clear()

    /** Susun prompt dengan format giliran Gemma. */
    private fun buildPrompt(system: String): String {
        var turns = history.takeLast(7)
        var text: String
        while (true) {
            val sb = StringBuilder()
            turns.forEachIndexed { i, (role, content) ->
                if (role == "user") {
                    sb.append("<start_of_turn>user\n")
                    if (i == 0) sb.append(system).append("\n\n")
                    sb.append(content).append("<end_of_turn>\n")
                } else {
                    sb.append("<start_of_turn>model\n").append(content).append("<end_of_turn>\n")
                }
            }
            sb.append("<start_of_turn>model\n")
            text = sb.toString()
            // Jaga supaya prompt tidak melebihi batas token
            if (text.length <= 2600 || turns.size <= 1) break
            turns = turns.drop(2)
        }
        return text
    }

    fun close() {
        ready = false
        try { session?.close() } catch (_: Throwable) {}
        try { llm?.close() } catch (_: Throwable) {}
        session = null
        llm = null
    }
}
