package com.example.mochi

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.hypot
import kotlin.math.max

/**
 * Service yang menampilkan maskot melayang di atas semua aplikasi:
 * ketuk maskot untuk membuka kotak ketik + mic, tarik untuk memindahkan.
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.example.mochi.STOP"
        private const val CHANNEL_ID = "mochi"
        private const val NOTIF_ID = 1
    }

    private lateinit var wm: WindowManager
    private lateinit var imm: InputMethodManager
    private lateinit var prefs: Prefs
    private lateinit var engine: LlmEngine
    private lateinit var lp: WindowManager.LayoutParams

    private lateinit var root: LinearLayout
    private lateinit var bubble: TextView
    private lateinit var mascot: MascotView
    private lateinit var inputRow: LinearLayout
    private lateinit var input: EditText

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var inputOpen = false
    private var busy = false
    private var viewAdded = false

    private val hideBubble = Runnable { if (!inputOpen && !busy) bubble.visibility = View.GONE }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
        engine = LlmEngine(this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager

        startAsForeground()
        buildUi()

        try {
            wm.addView(root, lp)
            viewAdded = true
        } catch (e: Exception) {
            // Izin "tampil di atas aplikasi lain" belum diberikan
            stopSelf()
            return
        }

        if (prefs.speak) {
            tts = TextToSpeech(this) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    tts?.language = Locale("id", "ID")
                    ttsReady = true
                }
            }
        }
        scope.launch { loadModel() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) stopSelf()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        scope.cancel()
        try { recognizer?.destroy() } catch (_: Throwable) {}
        try { tts?.shutdown() } catch (_: Throwable) {}
        engine.close()
        if (viewAdded) try { wm.removeView(root) } catch (_: Throwable) {}
        super.onDestroy()
    }

    // ---------------------------------------------------------------- notifikasi

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Mochi aktif", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("${prefs.aiName} lagi nemenin kamu")
            .setContentText("Ketuk untuk buka pengaturan")
            .setContentIntent(open)
            .addAction(0, "Hentikan", stop)
            .setOngoing(true)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, NOTIF_ID, n, type)
    }

    // ---------------------------------------------------------------- tampilan

    private fun buildUi() {
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            // Jangkar di kiri-bawah supaya maskot tidak "loncat" saat balon chat muncul
            gravity = Gravity.BOTTOM or Gravity.START
            x = dp(16)
            y = dp(140)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }

        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        // --- baris ketik (atas)
        inputRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
            background = rounded(0xF0101820.toInt(), 0xFF5CC48A.toInt(), 18)
            setPadding(dp(10), dp(4), dp(4), dp(4))
        }
        input = EditText(this).apply {
            hint = "Ketik atau pencet 🎤"
            setHintTextColor(0x99FFFFFF.toInt())
            setTextColor(Color.WHITE)
            textSize = 14f
            maxLines = 3
            background = null
            imeOptions = EditorInfo.IME_ACTION_SEND
            setSingleLine(false)
            setHorizontallyScrolling(false)
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) { submit(); true } else false
            }
        }
        val mic = smallButton("🎤") { listen() }
        val send = smallButton("➤") { submit() }
        inputRow.addView(input, LinearLayout.LayoutParams(dp(180), LinearLayout.LayoutParams.WRAP_CONTENT))
        inputRow.addView(mic)
        inputRow.addView(send)

        // --- balon bicara
        bubble = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 13.5f
            typeface = Typeface.DEFAULT
            maxWidth = dp(260)
            visibility = View.GONE
            background = rounded(0xF0101820.toInt(), 0xFF5CC48A.toInt(), 16)
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }

        // --- maskot (bawah)
        mascot = MascotView(this)
        mascot.setOnTouchListener(DragListener())

        root.addView(inputRow, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(6) })
        root.addView(bubble, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(4) })
        root.addView(mascot)
    }

    private fun rounded(fill: Int, stroke: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(fill)
        setStroke(dp(1), stroke)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun smallButton(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        setTextColor(Color.WHITE)
        textSize = 16f
        background = null
        minWidth = dp(40)
        minimumWidth = dp(40)
        setPadding(0, 0, 0, 0)
        setOnClickListener { onClick() }
    }

    /** Tarik = pindah posisi, ketuk = buka/tutup kotak ketik. */
    private inner class DragListener : View.OnTouchListener {
        private var startX = 0f
        private var startY = 0f
        private var origX = 0
        private var origY = 0
        private var moved = false
        private val slop = ViewConfiguration.get(this@OverlayService).scaledTouchSlop

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = e.rawX; startY = e.rawY
                    origX = lp.x; origY = lp.y
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - startX
                    val dy = e.rawY - startY
                    if (!moved && hypot(dx, dy) > slop) moved = true
                    if (moved) {
                        lp.x = max(0, (origX + dx).toInt())
                        lp.y = max(0, (origY - dy).toInt()) // gravity bawah: y dihitung dari bawah
                        wm.updateViewLayout(root, lp)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) setInputOpen(!inputOpen)
            }
            return true
        }
    }

    private fun setInputOpen(open: Boolean) {
        inputOpen = open
        inputRow.visibility = if (open) View.VISIBLE else View.GONE
        lp.flags = if (open) {
            lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        } else {
            lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        }
        wm.updateViewLayout(root, lp)
        if (open) {
            handler.removeCallbacks(hideBubble)
            input.requestFocus()
            input.post { imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT) }
        } else {
            imm.hideSoftInputFromWindow(input.windowToken, 0)
            handler.postDelayed(hideBubble, 6000)
        }
    }

    // ---------------------------------------------------------------- obrolan

    private suspend fun loadModel() {
        val f = prefs.modelFile
        if (!f.exists()) {
            say("Aku belum punya otak 😅 Buka app Mochi, lalu pilih file model dulu ya.", keep = true)
            return
        }
        mascot.mood = MascotView.Mood.THINKING
        say("Bentar ya, aku lagi bangun…", keep = true)
        try {
            engine.load(f.absolutePath)
            mascot.mood = MascotView.Mood.IDLE
            val who = prefs.userName.ifBlank { "" }
            say("Hai $who! Aku ${prefs.aiName}. Colek aku kalau mau ngobrol 💚".replace("Hai !", "Hai!"))
        } catch (e: Throwable) {
            mascot.mood = MascotView.Mood.IDLE
            say("Gagal memuat model: ${e.message?.take(120)}", keep = true)
        }
    }

    private fun submit() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        input.setText("")
        send(text)
    }

    private fun send(text: String) {
        if (busy) return
        if (!engine.ready) { say("Aku belum siap, tunggu sebentar ya."); return }
        busy = true
        mascot.mood = MascotView.Mood.THINKING
        say("…", keep = true)
        val reply = StringBuilder()

        engine.ask(text, prefs.systemPrompt()) { partial, done ->
            handler.post {
                if (partial.isNotEmpty()) {
                    mascot.mood = MascotView.Mood.TALKING
                    reply.append(partial)
                    setBubble(clean(reply.toString()))
                }
                if (done) {
                    busy = false
                    mascot.mood = MascotView.Mood.IDLE
                    val finalText = clean(reply.toString())
                    engine.remember(finalText)
                    if (finalText.isEmpty()) setBubble("(aku bengong… coba tanya lagi)")
                    else if (prefs.speak && ttsReady) {
                        tts?.speak(finalText, TextToSpeech.QUEUE_FLUSH, null, "mochi")
                    }
                    if (!inputOpen) handler.postDelayed(hideBubble, 14000)
                }
            }
        }
    }

    private fun clean(s: String) = s.replace("<end_of_turn>", "").replace("<start_of_turn>", "").trim()

    private fun say(text: String, keep: Boolean = false) {
        setBubble(text)
        handler.removeCallbacks(hideBubble)
        if (!keep && !inputOpen) handler.postDelayed(hideBubble, 8000)
    }

    private fun setBubble(text: String) {
        bubble.text = if (text.length > 420) "…" + text.takeLast(420) else text
        bubble.visibility = View.VISIBLE
        handler.removeCallbacks(hideBubble)
    }

    // ---------------------------------------------------------------- suara

    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            say("Buka app Mochi dulu buat kasih izin mikrofon ya.")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("HP-mu belum punya layanan pengenal suara.")
            return
        }
        try { recognizer?.destroy() } catch (_: Throwable) {}
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { say("Aku dengerin…", keep = true) }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onError(error: Int) { say("Nggak kedengeran, coba lagi ya.") }
                override fun onResults(results: Bundle?) {
                    val text = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                    if (text.isNullOrBlank()) say("Nggak kedengeran, coba lagi ya.") else send(text)
                }
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        }
        recognizer?.startListening(i)
    }
}
