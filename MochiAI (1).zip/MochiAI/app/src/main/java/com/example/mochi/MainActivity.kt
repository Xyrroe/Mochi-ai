package com.example.mochi

import android.Manifest
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/** Layar pengaturan: kasih izin, pilih file model AI, atur nama & kepribadian, lalu mulai. */
class MainActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var status: TextView
    private lateinit var etAi: EditText
    private lateinit var etUser: EditText
    private lateinit var etPersona: EditText
    private lateinit var swSpeak: SwitchCompat
    private var copying = false

    private val pickModel =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) copyModel(uri)
        }

    private val askPerms =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { refresh() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(28))
        }
        setContentView(ScrollView(this).apply { addView(col) })

        col.addView(TextView(this).apply {
            text = "Mochi 🌱"
            textSize = 28f
        })
        col.addView(TextView(this).apply {
            text = "Asisten AI pribadi yang hidup langsung di HP-mu, jalan offline."
            setPadding(0, dp(4), 0, dp(16))
        })

        status = TextView(this).apply { setPadding(0, 0, 0, dp(12)) }
        col.addView(status)

        col.addView(button("1. Izinkan tampil di atas aplikasi lain") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        col.addView(button("2. Izinkan mikrofon & notifikasi") {
            val list = mutableListOf(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
            askPerms.launch(list.toTypedArray())
        })
        col.addView(button("3. Pilih file model AI (.task)") { pickModel.launch(arrayOf("*/*")) })

        col.addView(label("Nama asistenmu"))
        etAi = field(prefs.aiName)
        col.addView(etAi)
        col.addView(label("Nama panggilanmu"))
        etUser = field(prefs.userName)
        col.addView(etUser)
        col.addView(label("Kepribadiannya"))
        etPersona = field(prefs.persona)
        etPersona.minLines = 2
        col.addView(etPersona)

        swSpeak = SwitchCompat(this).apply {
            text = "Bacakan jawaban dengan suara"
            isChecked = prefs.speak
            setPadding(0, dp(12), 0, dp(12))
        }
        col.addView(swSpeak)

        col.addView(button("▶ Mulai") { start() })
        col.addView(button("■ Hentikan") {
            stopService(Intent(this, OverlayService::class.java))
            refresh()
        })

        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onPause() {
        saveFields()
        super.onPause()
    }

    private fun label(t: String) = TextView(this).apply {
        text = t
        setPadding(0, dp(12), 0, 0)
    }

    private fun field(initial: String) = EditText(this).apply {
        setText(initial)
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }

    private fun button(t: String, onClick: () -> Unit) = MaterialButton(this).apply {
        text = t
        isAllCaps = false
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) }
        setOnClickListener { onClick() }
    }

    private fun saveFields() {
        if (!::etAi.isInitialized) return
        prefs.aiName = etAi.text.toString().trim()
        prefs.userName = etUser.text.toString().trim()
        prefs.persona = etPersona.text.toString().trim()
        prefs.speak = swSpeak.isChecked
    }

    private fun serviceRunning(): Boolean {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        @Suppress("DEPRECATION")
        return am.getRunningServices(Int.MAX_VALUE).any { it.service.className == OverlayService::class.java.name }
    }

    private fun refresh() {
        val overlay = Settings.canDrawOverlays(this)
        val mic = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        val model = prefs.modelFile
        val modelText = if (model.exists()) "✅ ada (${model.length() / 1_000_000} MB)" else "❌ belum dipilih"
        status.text = buildString {
            appendLine(if (overlay) "✅ Tampil di atas aplikasi lain" else "❌ Tampil di atas aplikasi lain")
            appendLine(if (mic) "✅ Mikrofon" else "❌ Mikrofon (opsional, untuk bicara)")
            appendLine("Model AI: $modelText")
            if (copying) appendLine("⏳ Sedang menyalin model…")
            append(if (serviceRunning()) "Status: Mochi sedang aktif 🌱" else "Status: Mochi belum jalan")
        }
    }

    private fun start() {
        saveFields()
        when {
            !Settings.canDrawOverlays(this) ->
                toast("Langkah 1 dulu: izinkan tampil di atas aplikasi lain.")
            !prefs.modelFile.exists() ->
                toast("Langkah 3 dulu: pilih file model AI.")
            copying -> toast("Tunggu, model masih disalin.")
            else -> {
                // Mulai ulang supaya nama/kepribadian terbaru terpakai
                stopService(Intent(this, OverlayService::class.java))
                ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
                toast("Mochi dimulai! Cek layar utamamu 🌱")
                window.decorView.postDelayed({ refresh() }, 800)
            }
        }
    }

    /** Salin file model ke penyimpanan app (MediaPipe butuh path file biasa). */
    private fun copyModel(uri: Uri) {
        if (copying) return
        copying = true
        refresh()
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val tmp = File(filesDir, "model.task.tmp")
                    contentResolver.openInputStream(uri)?.use { ins ->
                        FileOutputStream(tmp).use { out -> ins.copyTo(out, 1 shl 20) }
                    } ?: return@withContext false
                    prefs.modelFile.delete()
                    tmp.renameTo(prefs.modelFile)
                } catch (e: Exception) {
                    false
                }
            }
            copying = false
            toast(if (ok) "Model siap dipakai ✅" else "Gagal menyalin model (ruang penyimpanan cukup?)")
            refresh()
        }
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()
}
