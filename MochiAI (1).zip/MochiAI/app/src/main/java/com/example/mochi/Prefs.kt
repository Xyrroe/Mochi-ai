package com.example.mochi

import android.content.Context
import java.io.File

/** Pengaturan sederhana: nama, kepribadian, dan lokasi file model. */
class Prefs(private val context: Context) {
    private val sp = context.getSharedPreferences("mochi", Context.MODE_PRIVATE)

    var aiName: String
        get() = sp.getString("aiName", "Mochi") ?: "Mochi"
        set(v) = sp.edit().putString("aiName", v.ifBlank { "Mochi" }).apply()

    var userName: String
        get() = sp.getString("userName", "") ?: ""
        set(v) = sp.edit().putString("userName", v).apply()

    var persona: String
        get() = sp.getString("persona", DEFAULT_PERSONA) ?: DEFAULT_PERSONA
        set(v) = sp.edit().putString("persona", v.ifBlank { DEFAULT_PERSONA }).apply()

    var speak: Boolean
        get() = sp.getBoolean("speak", false)
        set(v) = sp.edit().putBoolean("speak", v).apply()

    val modelFile: File get() = File(context.filesDir, "model.task")

    /** Instruksi dasar yang dikirim ke AI di awal setiap percakapan. */
    fun systemPrompt(): String {
        val who = if (userName.isBlank()) "pemilik HP ini" else userName
        return "Kamu adalah $aiName, asisten AI pribadi milik $who yang hidup langsung di HP-nya. " +
            "Kepribadianmu: $persona. " +
            "Jawab dalam bahasa Indonesia santai, singkat (maksimal 3 kalimat), " +
            "dan jangan pernah bilang kamu adalah model bahasa besar."
    }

    companion object {
        const val DEFAULT_PERSONA = "ceria, sedikit jahil, perhatian, dan suka menyemangati"
    }
}
