# Mochi 🌱 — asisten AI offline yang melayang di HP Android

Maskot kecil yang nongol di atas semua aplikasi. Ketuk untuk ngobrol (ketik atau pakai mic), tarik untuk dipindah.
AI-nya jalan 100% di HP (MediaPipe LLM Inference + Gemma), tanpa internet dan tanpa API key.

Maskotnya karakter orisinal (digambar dengan kode di `MascotView.kt`), jadi gampang diganti.

## Cara menjalankan

1. Pasang **Android Studio** di laptop/PC, lalu **Open** folder `MochiAI` ini. Tunggu Gradle sync selesai
   (Android Studio akan membuatkan Gradle wrapper sendiri).
2. Aktifkan **Opsi Pengembang** + **USB debugging** di HP, colok ke laptop, lalu tekan **Run ▶**.
   (Emulator tidak disarankan, MediaPipe LLM tidak stabil di emulator.)
3. Download model di HP-mu:
   - Buka https://huggingface.co/litert-community/Gemma3-1B-IT, login, dan terima lisensi Gemma.
   - Unduh file `gemma3-1b-it-int4.task` (±530 MB).
4. Buka app **Mochi** di HP, lalu ikuti 3 tombol:
   1. Izinkan tampil di atas aplikasi lain
   2. Izinkan mikrofon & notifikasi
   3. Pilih file model `.task` tadi (disalin ke penyimpanan app, tunggu sebentar)
5. Isi nama asistenmu, namamu, dan kepribadiannya, lalu tekan **▶ Mulai**.

## Pemakaian

- **Ketuk maskot** → muncul kotak ketik + tombol 🎤 + kirim. Ketuk lagi untuk menutup.
- **Tarik maskot** → pindah posisi.
- **Hentikan** → tombol di notifikasi atau di app.

## Kebutuhan HP

- Android 8.0+, disarankan RAM 6 GB ke atas (HP kelas atas lebih lancar).
- Ruang kosong ±1,5 GB (file asli + salinan di app; setelah selesai file asli boleh dihapus).

## Catatan penting

- Kode ini **belum pernah dikompilasi atau dites di perangkat** (tidak ada Android SDK di tempat aku menulisnya).
  Kalau ada error saat build, kirim pesan error-nya, nanti kuperbaiki.
- Format prompt di `LlmEngine.kt` memakai format Gemma. Kalau mau ganti model lain (Qwen, Llama, dll),
  ubah fungsi `buildPrompt`.
- Ingatan obrolan cuma sebentar (±7 giliran terakhir) dan hilang saat Mochi dihentikan.
- Pengenalan suara memakai layanan bawaan HP (`SpeechRecognizer`), bisa offline kalau paket bahasa Indonesia
  sudah diunduh di pengaturan Google/keyboard.
- Ukuran overlay dan posisi keyboard bisa beda antar merek HP; kalau kotak ketik tertutup keyboard, tarik maskotnya ke atas.

## Struktur

- `OverlayService.kt` — jendela melayang, balon chat, drag, mic, suara
- `LlmEngine.kt` — memuat model dan menghasilkan jawaban (streaming)
- `MascotView.kt` — gambar & animasi maskot
- `MainActivity.kt` — layar pengaturan
- `Prefs.kt` — nama, kepribadian, prompt dasar

## Build tanpa laptop (GitHub)

Repo ini sudah berisi `.github/workflows/build.yml`. Setiap kali kode di-push ke GitHub, APK dibuat otomatis:
buka tab **Releases** di repo (atau **Actions → run terbaru → Artifacts**) dan unduh `Mochi.apk`.
Lalu pasang di HP (izinkan "install dari sumber tidak dikenal").
